#chrisstellaB

O = 1
while O < 13:
    print(f"{O}AM")
    O = O + 1

M = 1
while M < 13:
    print(f"{M}PM")
    M = M + 1
