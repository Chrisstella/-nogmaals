i = 0
T = 50
while i < 1000:
    i = i + T
    T = T + 1
    print(i)