#Chrisstella b

X = 20
while X <= 50:
    print(X)
    X = X + 2
