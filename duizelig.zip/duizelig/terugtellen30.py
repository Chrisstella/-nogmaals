#chrisstellaB

L = 30
while L > 0:
    print(L)
    L = L-1
print("Lancering!")